let profile = document.querySelector(".profile");
let menu = document.querySelector(".menu");


profile.addEventListener("click", ()=>{
    menu.classList.toggle("active")
})  