<?php
    $con = mysqli_connect("localhost", "root", "", "codeconnect") or die(myslq_error());

?>

